"""WebSocket connection/room manager."""

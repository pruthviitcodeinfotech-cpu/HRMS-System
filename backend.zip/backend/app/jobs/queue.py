"""Job queue configuration."""

"""Middleware: access + timing logging."""

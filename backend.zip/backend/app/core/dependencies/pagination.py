"""Dependency: pagination query parameters."""

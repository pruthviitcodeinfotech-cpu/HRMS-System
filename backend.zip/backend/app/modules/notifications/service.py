"""notifications: Service layer (business rules, transactions, orchestration). Foundation phase — empty."""

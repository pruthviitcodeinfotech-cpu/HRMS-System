"""notifications module package."""

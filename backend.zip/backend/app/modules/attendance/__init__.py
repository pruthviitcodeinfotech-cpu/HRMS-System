"""attendance module package."""

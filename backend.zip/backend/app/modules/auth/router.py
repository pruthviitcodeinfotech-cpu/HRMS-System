"""auth: API routes (thin controllers). Foundation phase — no endpoints yet."""

"""employee module package."""

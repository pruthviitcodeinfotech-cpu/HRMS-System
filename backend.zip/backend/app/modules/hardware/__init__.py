"""hardware module package."""

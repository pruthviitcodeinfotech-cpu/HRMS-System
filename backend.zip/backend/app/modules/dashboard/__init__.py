"""dashboard module package."""

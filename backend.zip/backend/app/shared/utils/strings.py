"""String utilities."""

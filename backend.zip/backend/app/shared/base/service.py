"""Base service class."""

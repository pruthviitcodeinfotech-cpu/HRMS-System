"""Paginated response schema."""
